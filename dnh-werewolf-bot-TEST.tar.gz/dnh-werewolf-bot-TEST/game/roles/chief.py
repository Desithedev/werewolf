from game.roles.villager import Villager


class Chief(Villager):
    # Chief of Villager is a Villager but the vote is counted as 2
    pass
