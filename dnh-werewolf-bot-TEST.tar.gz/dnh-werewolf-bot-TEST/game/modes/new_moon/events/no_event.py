from game.modes.new_moon.events.base import NewMoonEvent


class NoEvent(NewMoonEvent):
    KEY = "no_event"
